/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package exemple;

/**
 *
 * @author Olivier
 */
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.util.ArrayList;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.collections.transformation.FilteredList;
import javafx.collections.transformation.SortedList;
import javafx.fxml.FXML;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;

/**
 * View-Controller for the person table.
 *
 * @author Marco Jakob
 */
public class PersonTableController {

    @FXML
    private TextField filterField;
    @FXML
    private TableView<Contact> personTable;
    @FXML
    private TableColumn<Contact, String> firstNameColumn;
    @FXML
    private TableColumn<Contact, String> lastNameColumn;

    private ObservableList<Contact> masterData = FXCollections.observableArrayList();

    /**
     * Just add some sample data in the constructor.
     */
    //lecture
    public PersonTableController() {

        ArrayList<ArrayList> arrayparent = new ArrayList<ArrayList>();
        ArrayList<String> arrayfils = new ArrayList<String>();
        try {

            FileInputStream fileIn = new FileInputStream("C:\\Users\\Olivier\\Documents\\EXO\\Carnet_Adresse\\contact.dat");
            ObjectInputStream ois = new ObjectInputStream(fileIn);
            arrayparent = (ArrayList) ois.readObject();
            ois.close();
            fileIn.close();
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        } catch (ClassNotFoundException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }

        for(ArrayList o:arrayparent){
      masterData.add(new Contact((String)o.get(0),(String)o.get(1)));
      
        }
        
       
        masterData.add(new Contact("Pedor", "El Coco"));
        masterData.add(new Contact("Ruth", "Mueller"));
        masterData.add(new Contact("Heinz", "Kurz"));
        masterData.add(new Contact("Cornelia", "Meier"));
        masterData.add(new Contact("Werner", "Meyer"));
        masterData.add(new Contact("Lydia", "Kunz"));
        masterData.add(new Contact("Anna", "Best"));
        masterData.add(new Contact("Stefan", "Meier"));
        masterData.add(new Contact("Martin", "Mueller"));
    }

    /**
     * Initializes the controller class. This method is automatically called
     * after the fxml file has been loaded.
     *
     * Initializes the table columns and sets up sorting and filtering.
     */
    @FXML
    private void initialize() {
        // 0. Initialize the columns.
        firstNameColumn.setCellValueFactory(cellData -> cellData.getValue().firstNameProperty());
        lastNameColumn.setCellValueFactory(cellData -> cellData.getValue().lastNameProperty());

        // 1. Wrap the ObservableList in a FilteredList (initially display all data).
        FilteredList<Contact> filteredData = new FilteredList<>(masterData, p -> true);

        // 2. Set the filter Predicate whenever the filter changes.
        filterField.textProperty().addListener((observable, oldValue, newValue) -> {
            filteredData.setPredicate(person -> {
                // If filter text is empty, display all persons.
                if (newValue == null || newValue.isEmpty()) {
                    return true;
                }

                // Compare first name and last name of every person with filter text.
                String lowerCaseFilter = newValue.toLowerCase();

                if (person.getFirstName().toLowerCase().indexOf(lowerCaseFilter) != -1) {
                    return true; // Filter matches first name.
                } else if (person.getLastName().toLowerCase().indexOf(lowerCaseFilter) != -1) {
                    return true; // Filter matches last name.
                }
                return false; // Does not match.
            });
        });

        // 3. Wrap the FilteredList in a SortedList. 
        SortedList<Contact> sortedData = new SortedList<>(filteredData);

        // 4. Bind the SortedList comparator to the TableView comparator.
        // 	  Otherwise, sorting the TableView would have no effect.
        sortedData.comparatorProperty().bind(personTable.comparatorProperty());

        // 5. Add sorted (and filtered) data to the table.
        personTable.setItems(sortedData);
    }
}
